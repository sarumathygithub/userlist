import 'package:flutter/material.dart';
import 'package:userlist/UI/UserList/UserListModel.dart';
import 'package:userlist/UI/UserList/UserListViewModel.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

 UserListViewModel userListViewModel = UserListViewModel();
 bool loading = true;
 UserList? userData;


  @override
  void initState() {
    userDataFetch();
    super.initState();
  }


  Future <void> userDataFetch() async{
    userData = await userListViewModel.fetchUsers();
    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      appBar: AppBar(
        title: Text('Home Page'),
      ),
      body: loading ? const Center(child: CircularProgressIndicator(),) :
      userData != null ? ListView.builder(
          itemCount: userData!.data.length,
          itemBuilder: (context,index){
            return Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(userData!.data[index].avatar),
                ),
                title: Text('${userData!.data[index].firstName} ${userData!.data[index].lastName}'),
                subtitle: Text(userData!.data[index].email),
              ),
            );
          }
      ) : const Center(child: CircularProgressIndicator(),),
    );
  }
}

