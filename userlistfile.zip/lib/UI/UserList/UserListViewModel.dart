import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:userlist/UI/UserList/UserListModel.dart';

class UserListViewModel{

  List userData=[];

   Future<UserList?> fetchUsers() async{
    const url = "https://reqres.in/api/users?page=1";
    final uri = Uri.parse(url);
    final response = await http.get(uri);
    final json = jsonDecode(response.body);
    final userData = userListFromJson(json);
    if (response.statusCode == 200){
      return userData;
    }else{
      return null;
    }
  }
}

